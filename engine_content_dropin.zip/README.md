# Engine Content Drop-in

This package contains two canonical lesson JSON packets in repo-ready placement:

- `engine/content/science9_interconnected_spheres.json`
- `engine/content/careers8_goal_setting.json`

These were checked for the documented top-level engine contract:
- lesson metadata
- slides array
- differentiated worksheet tiers
- self-checks
- answer keys
- rubrics
- teacher extension
- lesson plan

## Next commands in your real repo

```bash
node engine/pptx/build.js --lesson engine/content/science9_interconnected_spheres.json --out ./output/
python3 engine/pdf/build.py --lesson engine/content/science9_interconnected_spheres.json --out ./output/

node engine/pptx/build.js --lesson engine/content/careers8_goal_setting.json --out ./output/
python3 engine/pdf/build.py --lesson engine/content/careers8_goal_setting.json --out ./output/
```

## Important note

The actual `engine/` builders were not present in this workspace, so those exact build commands could not be executed here.
